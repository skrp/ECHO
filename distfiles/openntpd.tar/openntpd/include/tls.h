/*
 * Public domain
 * tls.h compatibility shim
 */

#ifdef HAVE_LIBTLS
#include_next <tls.h>
#endif
