/*
 * This file is in the public domain.
 *
 * adjfreq is native on OpenBSD, but we need to stub in update_time_sync_status
 */

void
update_time_sync_status(int synced)
{
}
