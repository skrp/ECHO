#!/bin/sh
exec autoreconf
